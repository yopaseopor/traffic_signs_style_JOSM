# traffic_signs_style_JOSM
Translated project from JOSM Styles due to exceed limit and expand to other countries.
