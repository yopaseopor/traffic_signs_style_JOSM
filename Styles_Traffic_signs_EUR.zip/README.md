[![Build Status](https://travis-ci.org/yopaseopor/traffic_signs_style_JOSM.svg?branch=master)](https://travis-ci.org/yopaseopor/traffic_signs_style_JOSM)
# traffic_signs_style_JOSM
Translated project from JOSM Styles due to exceed limit and expand to other countries.

